# Clear R's environment
rm(list = ls())

# Loading the tidyverse package
library(tidyverse)

# FTP path (URL) to a GFF file
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/922/385/GCA_001922385.1_ASM192238v1/GCA_001922385.1_ASM192238v1_genomic.gff.gz" # Sphingomonas koreensis
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/010/305/GCA_000010305.1_ASM1030v1/GCA_000010305.1_ASM1030v1_genomic.gff.gz" # Gemmatimonas aurantiaca T-27
#url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/020/546/685/GCA_020546685.1_ASM2054668v1/GCA_020546685.1_ASM2054668v1_genomic.gff.gz" # Deinococcus radiodurans R1
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read_tsv(file=filename, col_names=FALSE, comment="#")
dim(d)
TF <- grepl(pattern="16S ribosomal RNA", x=unlist(d[,9])); summary(TF)
( length_sequence_pattern <- unlist(d[TF,5] - d[TF,4] + 1) )
( length_sequence_total <- unlist(d[1,5] - d[1,4] + 1) )
100 * median(length_sequence_pattern) / length_sequence_total

#' # Links
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Sphingomonas
#' - Sphingomonas koreensis
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_001922385.1
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/001/922/385/GCA_001922385.1_ASM192238v1/
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Gemmatimonas
#' - Gemmatimonas aurantiaca T-27
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_000010305.1
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/000/010/305/GCA_000010305.1_ASM1030v1/
#' 
#' - https://www.ncbi.nlm.nih.gov/genome/browse/#!/prokaryotes/Deinococcus
#' - Deinococcus radiodurans R1 = ATCC 13939 = DSM 20539
#' - https://www.ncbi.nlm.nih.gov/assembly/GCA_020546685.1
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCA/020/546/685/GCA_020546685.1_ASM2054668v1/

sessionInfo()
Sys.time()
