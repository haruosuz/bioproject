# Clear R's environment
rm(list = ls())

# Loading the tidyverse package
library(tidyverse)

# Reading a CSV file into R
mydir <- "." 
( myfile <- list.files(path=mydir, pattern=".csv$", full.names=TRUE) )
d <- read_csv(myfile); dim(d); d <- d[,-1]; d <- as.data.frame(t(d)); d <- d %>% arrange(desc(V1))

# Writing the processed data to a TSV file
write.table(d, file=paste0("R.LEA.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)

sessionInfo()
Sys.time()
