# Clear R's environment
rm(list = ls())

# Loading the tidyverse package
library(tidyverse)

# FTP path (URL) to a GFF file
url <- ""
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/555/GCF_028743555.1_ASM2874355v1/GCF_028743555.1_ASM2874355v1_genomic.gff.gz" # Escherichia coli B-1109
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/595/GCF_028743595.1_ASM2874359v1/GCF_028743595.1_ASM2874359v1_genomic.gff.gz" # Pseudomonas aeruginosa B-3509
url <- "https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/615/GCF_028743615.1_ASM2874361v1/GCF_028743615.1_ASM2874361v1_genomic.gff.gz" # Staphylococcus aureus B-41012
filename <- basename(url)
if(!file.exists(filename)) download.file(url = url, destfile = filename)

# Loading Data into R
d <- read_tsv(file=filename, col_names=FALSE, comment="#")
dim(d)
TF <- grepl(pattern="ID=rna.*16S ribosomal RNA", x=unlist(d[,9])); summary(TF)
( length_sequence_pattern <- unlist(d[TF,5] - d[TF,4] + 1) )
( length_sequence_total <- unlist(d[1,5] - d[1,4] + 1) )
100 * sum(length_sequence_pattern) / length_sequence_total

#' # Links
#' - https://files.zymoresearch.com/protocols/_d6300_zymobiomics_microbial_community_standard.pdf
#' - 
#' - Escherichia coli B-1109 CP117971 CP117972
#' - https://www.ncbi.nlm.nih.gov/bioproject/PRJNA933698
#' - https://www.ncbi.nlm.nih.gov/datasets/genome/GCA_028743555.1/
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/555/GCF_028743555.1_ASM2874355v1/
#' - 
#' - Pseudomonas aeruginosa B-3509 CP117974 CP117975
#' - https://www.ncbi.nlm.nih.gov/nuccore/CP117974
#' - https://www.ncbi.nlm.nih.gov/bioproject/PRJNA933701
#' - https://www.ncbi.nlm.nih.gov/datasets/genome/GCA_028743595.1/
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/595/GCF_028743595.1_ASM2874359v1/
#' - 
#' - Staphylococcus aureus B-41012 CP117979 CP117981
#' - https://www.ncbi.nlm.nih.gov/nuccore/CP117981
#' - https://www.ncbi.nlm.nih.gov/bioproject/PRJNA933703
#' - https://www.ncbi.nlm.nih.gov/datasets/genome/GCA_028743615.1/
#' - https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/028/743/615/GCF_028743615.1_ASM2874361v1/
#' 
sessionInfo()
Sys.time()
