# Clear R's environment
rm(list = ls())

# Loading the tidyverse package
library(tidyverse)

# Loading Data into R
mydir <- "./VITCOMIC2_results/"
( myfile <- list.files(path=mydir, pattern=".genus.txt", full.names=TRUE) )
d <- read.delim(file=myfile, stringsAsFactors=FALSE, header = FALSE) # na.strings="-", quote="", check.names=FALSE

# Exploring and Transforming Dataframes
dim(d)
colnames(d) <- c("genus", "phylum_class", "Nreads")
sum(d$Nreads)
x <- summarise(group_by(d, `phylum_class`), sum.Nreads = sum(Nreads))
x <- mutate(x, pct.sum.Nreads = 100 * x$sum.Nreads / sum(x$sum.Nreads) ) %>% arrange(desc(sum.Nreads))
x
d$pct.Nreads <- 100 * d$Nreads / sum(d$Nreads)
d <- d[order(d[,3], decreasing=TRUE),]
write.table(d, file=paste0("R.VITCOMIC.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)

sessionInfo()
Sys.time()

