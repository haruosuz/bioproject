#' - http://133.39.177.105/lea/help_en.html
#' "Project ID"

# Clear R's environment
rm(list = ls())

# Load CSV files from the specified directory
mydir <- "." 
( myfile <- list.files(path=mydir, pattern=".csv$", full.names=TRUE) )
if (length(myfile) == 0) { stop("No files found in the specified directory.") }
d <- read.csv(myfile, check.names=FALSE, stringsAsFactors=FALSE)
dim(d); d <- d[,-1]; d <- as.data.frame(t(d))
d <- d[order(d[,1], decreasing=TRUE), , drop = FALSE]; is.data.frame(d)
write.table(d, file=paste0("R.LEA.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)

# Display session information and the current time
sessionInfo()
Sys.time()
