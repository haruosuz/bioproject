# Clear all objects from the environment
rm(list = ls())

# Load data from the specified directory
mydir <- "./result/VITCOMIC_result"
(myfile <- list.files(path=mydir, pattern=".genus.txt", full.names=TRUE))

# Check if any files are found
if (length(myfile) == 0) { stop("No files found in the specified directory.") }
d <- read.delim(file=myfile, stringsAsFactors=FALSE, header=FALSE)

dim(d) # Check dimensions of the dataset
colnames(d) <- c("genus", "phylum_class", "read_count") # Assign column names
sum(d$read_count) # Calculate total number of reads (read_count)

# Group data by phylum_class and calculate the total reads per group
x <- aggregate(read_count ~ phylum_class, data=d, sum)
# Calculate percentage of total reads for each phylum_class
x$pct_read_count <- 100 * x$read_count / sum(x$read_count)
# Sort the data in descending order of total reads
x[order(x$read_count, decreasing=TRUE), ]

# Calculate the percentage of reads for each genus in the original data
d$pct_read_count <- 100 * d$read_count / sum(d$read_count)

# Sort the original data in descending order of reads using the column name
d <- d[order(d$read_count, decreasing=TRUE),]

# Save the result as a TSV file
write.table(d, file=paste0("R.VITCOMIC.",basename(myfile),".tsv"), sep="\t", quote=FALSE, row.names=TRUE, col.names=NA)

# Display session information and the current time
sessionInfo()
Sys.time()
